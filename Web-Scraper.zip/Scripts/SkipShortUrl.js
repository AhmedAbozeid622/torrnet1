const rp = require("request-promise");
const $ = require("cheerio");

let SkipShortUrl = async (url) => {
  return rp(url)
    .then(
      await function (html) {
        //success!

        let AkwamDownloadSkipLink;
        let AkwamDownloadLink;
        let AkwamDownloadTitle;

        // var count =  ($('h1', html).text());
        if (
          $(
            'a[class="download-link"]',
            html
          )[0].children[0].parent.attribs.href.includes("download")
        ) {
          AkwamDownloadSkipLink = $('a[class="download-link"]', html)[0]
            .children[0].parent.attribs.href;
        }
        return rp(AkwamDownloadSkipLink).then((HTML) => {
          HTML = HTML.split(/attr\(/g)[2]
            .split(/;/g)[0]
            .split(/'/g)[3];

          let qualitys = ["480p", "720p", "1080p"];

          let title = (data) => {
            for (let i = 0; i < qualitys.length; i++) {
              if (data.toUpperCase().includes(qualitys[i].toUpperCase())) {
                return qualitys[i];
              }
            }
          };

          AkwamDownloadLink = HTML;
          AkwamDownloadTitle = title(HTML) == null ? "UNKNOWN" : title(HTML);

          let AkwamData = {
            Link: AkwamDownloadLink,
            Title: AkwamDownloadTitle
          };
          return AkwamData;
        });
      }
    )
    .catch(function (err) {
      //handle error
      console.log(err);
    });
};

module.exports = SkipShortUrl;
// SkipShortUrl("https://go.akwam.cx/link/49558").then((d) => {
//   console.log(d);
// });