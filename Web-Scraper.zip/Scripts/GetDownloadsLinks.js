const rp = require("request-promise");
const $ = require("cheerio");

const GetDownloadsLinks =  function (url) {
  return rp(url)
    .then(function (html) {
      //success!
      const AkwamDownloadLinks = [];
      // const AkwamDownloadTitle = $("h1", html).text();
      var count = $("a", html).length;
      // var count =  ($('h1', html).text());
      for (let i = 0; i < count; i++) {
        if ($("a", html)[i].attribs.href.includes("link") == true) {
          let Link = new URL($("a", html)[i].attribs.href);
          Link.pathname.includes("link") == true ? AkwamDownloadLinks.push($("a", html)[i].attribs.href) : true
        }
      }
      var AkwamData = AkwamDownloadLinks;
      return AkwamData;
    })
    .catch(function (err) {
      //handle error
      console.log(err);
    });
};

module.exports = GetDownloadsLinks;
