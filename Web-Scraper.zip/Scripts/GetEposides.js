const rp = require("request-promise");
const $ = require("cheerio");

const GetEposides = function (url) {
  return rp(url)
    .then(function (html) {
      //success!
      const AkwamLinks = [];
      const AkwamTitles = [];
      var count = $(".text-white > a", html).length;
      for (let i = 0; i < count; i++) {
        if (
          $(".text-white > a", html)[i].attribs.href.includes("episode") == true
        ) {
          AkwamLinks.push($(".text-white > a", html)[i].attribs.href);
          AkwamTitles.push($(".text-white > a", html)[i].children[0].data);
        }
      }

      var AkwamData = { Links: AkwamLinks, Titles: AkwamTitles };
      return AkwamData;
    })
    .catch(function (err) {
      //handle error
      console.log(err);
    });
};

module.exports = GetEposides;