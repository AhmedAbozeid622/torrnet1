// server.js
// where your node app starts

// we've started you off with Express (https://expressjs.com/)
// but feel free to use whatever libraries or frameworks you'd like through `package.json`.
const express = require("express");
const path = require("path");
const app = express();
const rp = require("request-promise");
const $ = require("cheerio");
const GetEposides = require("./Scripts/GetEposides.js");
const GetDownloadsLinks = require("./Scripts/GetDownloadsLinks.js");
const SkipShortUrl = require("./Scripts/SkipShortUrl.js");
const https = require('https');
process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 0


const port = process.env.PORT || 5000;
app.use(express.static("public"));

app.get("/", (req, res) => {
  res.sendFile(`${__dirname}/views/index.html`);
});

app.use(express.json()); // built-in middleware for express

app.post("/Urls/", function (req, res) {
  var url = encodeURI(req.body.Url);
  // console.log(url);

  rp(url)
    .then(function (html) {
      //success!
      return GetEposides(url);
    })
    .then(function (Links) {
      // console.log(Links);
      res.send(Links);
    })
    .catch(function (err) {
      //handle error
      console.log(err);
    });
});
app.post("/Url/download", async(req, res) => {
  var url = encodeURI(req.body.Url);
  // console.log(url);
  var links = [];
  var titles = [];

  let bytesToSize = (bytes) => {
    var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes == 0) return '0 Byte';
    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
    return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
    }

  let https_r = async (link, data , count) => {
      https.get(link, async res => {
      let headerLength = res.headers && res.headers['content-length'] ? res.headers['content-length'] : 'no response data size';
      
        console.log(data[count-1] + " - " + bytesToSize(headerLength))
    
      
        titles.push(data[count-1] + " - " + bytesToSize(headerLength)); 

      
      
    
    }).on('error', err => {
      console.log('Error: ', err.message);
    });
  }

  let count;
  let split_Data;
  let f = async (link) => {
    return SkipShortUrl(link).then(async (data) => {
      links.push(data.Link);
      split_Data = data.Link.split('/');
      count = split_Data.length;
      https_r(data.Link,split_Data,count)

})

    
    };

  var counter;
  await GetDownloadsLinks(url)
    .then(async (Links) => {
      counter = Links.length;
      console.log(Links);
      let i = 0;
      while (i < Links.length) {
        await f(Links[i]);
        i++;
      }
    })
    async function init() {
      // console.log(1)
      await sleep(1);
      if(titles.length == counter){
        console.log('done')
      }
      else{
        await init()
      }
    } await init()
    function sleep(ms) {
      return new Promise((resolve) => {
        setTimeout(resolve, ms);
      });
    }  
    res.send({ Links: links, Titles: titles })


  // console.log(Links);
});

// app.get("/msg", (req, res) => {
//   var dataToSend;
//   // spawn new child process to call the python script
//   const python = spawn("python", ["script1.py"]);
//   // collect data from script
//   python.stdout.on("data", function (data) {
//     console.log("Pipe data from python script ...");
//     dataToSend = data.toString();
//   });
//   // in close event we are sure that stream from child process is closed
//   python.on("close", (code) => {
//     console.log(`child process close all stdio with code ${code}`);
//     // send data to browser
//     res.send(dataToSend);
//     console.log(dataToSend);
//   });
// });

// app.get("/api", async (req, res) => {
//   const webdriver = require("selenium-webdriver");
//   const chrome = require("selenium-webdriver/chrome");

//   let options = new chrome.Options();
//   options.setChromeBinaryPath(process.env.CHROME_BINARY_PATH);
//   let serviceBuilder = new chrome.ServiceBuilder(
//     process.env.CHROME_DRIVER_PATH
//   );

//   //Don't forget to add these for heroku
//   options.addArguments("--headless");
//   options.addArguments("--disable-gpu");
//   options.addArguments("--no-sandbox");

//   let driver = new webdriver.Builder()
//     .forBrowser("chrome")
//     .setChromeOptions(options)
//     .setChromeService(serviceBuilder)
//     .build();

//   await driver.get("http://www.google.com");
//   res.send(await driver.getTitle());
// });

// var link = "https://eg.akwam.co/show/episode/2340/%D9%86%D8%A7%D8%A8%D9%84%D9%8A%D9%88%D9%86"
// var link = encodeURI(link);

// rp(link)
// .then(function(html) {
//   //success!
//  return GetDownloadsLinks(link);
// })
// .then(function(Links) {
//   console.log(Links.Links);
//   console.log(Links.Titles)
//   // console.log(Links.link)
// })
// .catch(function(err) {
//   //handle error
//   console.log(err);
// });

// var link = "https://vidstream.kim/f/oA2vRbUPPp/?vclid=f4f9b899a8c76ffcc1e96430486f03e70f7c54206b93ca98f8d72963BeeezwAiFzeSezEHTdVdSCUbfXpFlSVFtSezSzezaDpezeSezitUyLTifaDOAsezSzezsaEezeSezsVLXOeOkiizijPVfeAXfAezem"
// var link = encodeURI(link);
// rp(link)
// .then(function(html) {
//   //success!
//  return test(link);
// })
// .then(function(Links) {
//   console.log(Links);
//   // console.log(Links.link)
// })
// .catch(function(err) {
//   //handle error
//   console.log(err);
// });

// listen for requests :)
const listener = app.listen(port, () => {
  console.log("Your app is listening on port " + listener.address().port);
});
