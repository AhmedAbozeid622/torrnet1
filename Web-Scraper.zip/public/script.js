function PostUrl() {
  let url = document.getElementById("Link").value;
  // document.getElementById("Link").value = ''
  const radio = [
    document.getElementById("btnradio1").checked,
    document.getElementById("btnradio2").checked
  ];
  if (radio[1]) {
    var StateDiv = document.getElementById("Links");
    StateDiv.innerHTML = "";
    StateDiv.className = "spinner-border text-success";

    var xhr = new XMLHttpRequest();
    xhr.open("POST", "/Urls", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(
      JSON.stringify({
        Url: url
      })
    );
    xhr.onload = function () {
      console.log("HELLO");
      console.log(this.responseText);
      var data = JSON.parse(this.responseText);
      console.log(data);
      var count = data.Links.length;
      const ShowCount = document.createElement("h2");
      const TextShowCount = document.createTextNode(
        "About " + count + " eposide(s)"
      );
      ShowCount.appendChild(TextShowCount);
      ShowCount.className = "list-group-item list-group-item-success";
      StateDiv.appendChild(ShowCount);
      StateDiv.appendChild(document.createElement("br"));

      function Generate_Link(i) {
        const ElementLink = document.createElement("a");
        const link = document.createTextNode(data.Titles[i]);
        ElementLink.appendChild(link);
        ElementLink.title = data.Titles[i];
        ElementLink.href = data.Links[i];
        ElementLink.className = "list-group-item list-group-item-action";
        ElementLink.target = "_blank";
        StateDiv.appendChild(ElementLink);
        StateDiv.appendChild(document.createElement("br"));
        return console.log(data.Links[i]);
        return console.log(data.Titles[i]);
      }
      for (let i = count - 1; i >= 0; --i) {
        Generate_Link(i);
      }
      StateDiv.className = "";
    };
  } else if (radio[0]) {
    var StateDiv = document.getElementById("Links");
    StateDiv.innerHTML = "";
    StateDiv.className = "spinner-border text-success";

    var xhr = new XMLHttpRequest();
    xhr.open("POST", "/Url/download", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(
      JSON.stringify({
        Url: url
      })
    );
    xhr.onload = function () {
      console.log("HELLO");
      console.log(this.responseText);
      var data = JSON.parse(this.responseText);
      console.log(data);
      var count = data.Links.length;
      const ShowCount = document.createElement("h2");
      const TextShowCount = document.createTextNode(
        "About " + count + " quality(s)"
      );
      ShowCount.appendChild(TextShowCount);
      ShowCount.className = "list-group-item list-group-item-success";
      StateDiv.appendChild(ShowCount);
      StateDiv.appendChild(document.createElement("br"));

      function Generate_Quality(i) {
        const ElementQuality = document.createElement("a");
        const link = document.createTextNode(data.Titles[i]);
        ElementQuality.appendChild(link);
        ElementQuality.title = data.Titles[i];
        ElementQuality.href = data.Links[i];
        ElementQuality.className = "list-group-item list-group-item-action";
        ElementQuality.target = "_blank";
        StateDiv.appendChild(ElementQuality);
        StateDiv.appendChild(document.createElement("br"));
        return console.log(data.Links[i]);
        return console.log(data.Titles[i]);
      }
      for (let i = count - 1; i >= 0; --i) {
        Generate_Quality(i);
      }
      StateDiv.className = "";
    };
  }
}

//##########################################################
